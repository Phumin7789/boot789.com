<?php require 'database/session.php';?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Admin Panel : User Management</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="./css/style.css">
  <link rel="stylesheet" type="text/css" href="./css/sidebar.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" integrity="sha256-39jKbsb/ty7s7+4WzbtELS4vq9udJ+MDjGTD5mtxHZ0=" crossorigin="anonymous" />
  <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
  <script type="text/javascript" src="./js/sidebar.js"></script>
</head>
<body>
  <div id="overlay">
    <div id="overlay-text">Processing..</div>
  </div>
  <?php
      require 'database/connection.php';
      $sql = " SELECT * FROM `setting` WHERE `id` = '1' ";
      $result = mysqli_query($db, $sql);
	  $data = mysqli_fetch_array($result, MYSQLI_ASSOC);
      require 'navbar.php';
     ?>



  <main class="content-wrapper">
    <div class="container-fluid">

      <div class="row">
        <div class="col">
          <h1 align="center" style="color: white;">ตั้งค่าเว็บไซต์</h1>
          <div align="center"></div>
        </div>
        <div class="col text-right">
          <a href="member.php" class="btn btn-outline-warning btn-lg"><i class="fas fa-reply-all"></i> Back</a>
        </div>
      </div>


      <div class="tab-content" id="nav-tabContent">

        <!-- Edit User Tab-->
        <div class="tab-pane fade show active" id="edit" role="tabpanel" aria-labelledby="edit-tab">
          <div class="container bg-dark" style="padding: 2%;">

            <div class="container text-warning" style="width: 80%;">
              <form action="database/editsetting.php" method="post">

                <div class="row">

                  <div class="col">
                    <div class="form-group">
                      <label></label>
                    </div>
                  </div>

                  <div class="col">
                    <div class="form-group">
                      <label></label>
                    </div>
                  </div>

                </div>

                <div class="row">

				<div class="col">
                    <div class="form-group">
                      <label>ชื่อเว็บ</label>
                      <input type="text" class="form-control" name="namesite" value="<?php echo $data['namesite'] ?>">
                    </div>
                  </div>
				  
                  <div class="col">
                    <div class="form-group">
                      <label>Title เว็บ/ชื่อหัวเว็บ</label>
                      <input type="text" class="form-control" name="title" value="<?php echo $data['title'] ?>">
                    </div>
                  </div>

                </div>

 

                  <div class="col">
                    <div class="form-group">
                      <label>Description</label>
                      <input type="text" class="form-control" name="description" value="<?php echo $data['description']; ?>">
                    </div>
                  </div>

                  <div class="col">
                    <div class="form-group">
                      <label>Keyword</label>
                      <input type="text" class="form-control" name="keyword" value="<?php echo $data['keyword'] ?>">
                    </div>
                  </div>
				<div class="col">
                    <div class="form-group">
                      <label>Logo หน้าล็อคอิน (ใส่เป็นลิงค์)</label>
                      <input type="text" class="form-control" name="imglogo" value="<?php echo $data['imglogo'] ?>">
                    </div>
                  </div>
				  <div class="col">
                    <div class="form-group">
                      <label>Logo หน้าเลือกสูตร และหน้าสูตร มุมซ้ายบน (ใส่เป็นลิงค์)</label>
                      <input type="text" class="form-control" name="imglogohome" value="<?php echo $data['imglogohome'] ?>">
                    </div>
                  </div>
				<div class="col">
                    <div class="form-group">
                      <label>พื้นหลังหน้า Login (ใส่เป็นลิงค์)</label>
                      <input type="text" class="form-control" name="bglogin" value="<?php echo $data['bglogin'] ?>">
                    </div>
                  </div>
				 <div class="col">
                    <div class="form-group">
                      <label>พื้นหลังหน้า เลือกสูตร (ใส่เป็นลิงค์)</label>
                      <input type="text" class="form-control" name="bghome" value="<?php echo $data['bghome'] ?>">
                    </div>
                  </div>
			  <div class="col">
				<div class="form-group">
				  <label>Line ติดต่อเว็บ</label>
				  <input type="text" class="form-control" name="line" value="<?php echo $data['line'] ?>">
				</div>
			  </div>
			   <div class="row">
			   <div class="col">
                    <div class="form-group">
                      <label>ตัดเครดิตค่า สูตรวิเคราะห์บอล</label>
                      <input type="text" class="form-control" name="decreditball" value="<?php echo $data['decreditball'] ?>">
                    </div>
                  </div>
				  <div class="col">
                    <div class="form-group">
                      <label>ตัดเครดิตค่า สูตรสล็อต</label>
                      <input type="text" class="form-control" name="decreditslot" value="<?php echo $data['decreditslot'] ?>">
                    </div>
                  </div>
			  </div>
			  <div>
			  <div class="row">	  
				  <div class="col">
					<div class="form-group">
					  <p><label>Slotpg <?php $status = $data['slotpg']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="slotpg">
					  <?php $status = $data['slotpg']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['slotpg']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>AllWaySpin <?php $status = $data['AllWaySpin']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="AllWaySpin">
					  <?php $status = $data['AllWaySpin']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['AllWaySpin']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Ameba <?php $status = $data['Ameba']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="Ameba">
					  <?php $status = $data['Ameba']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['Ameba']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Askmebet <?php $status = $data['Askmebet']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="Askmebet">
					  <?php $status = $data['Askmebet']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['Askmebet']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>booongo <?php $status = $data['booongo']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="booongo">
					  <?php $status = $data['booongo']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['booongo']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Dragon Soft <?php $status = $data['dragon']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="dragon">
					  <?php $status = $data['dragon']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['dragon']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Evoplay <?php $status = $data['Evoplay']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="Evoplay">
					  <?php $status = $data['Evoplay']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['Evoplay']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>FunTaGaming <?php $status = $data['FunTaGaming']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="FunTaGaming">
					  <?php $status = $data['FunTaGaming']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['FunTaGaming']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>gamatron <?php $status = $data['gamatron']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="gamatron">
					  <?php $status = $data['gamatron']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['gamatron']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Iconic Gaming <?php $status = $data['IconicGaming']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="IconicGaming">
					  <?php $status = $data['IconicGaming']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['IconicGaming']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>joker <?php $status = $data['joker']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="joker">
					  <?php $status = $data['joker']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['joker']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Kagaming <?php $status = $data['Kagaming']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="Kagaming">
					  <?php $status = $data['Kagaming']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['Kagaming']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>live22 <?php $status = $data['live22']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="live22">
					  <?php $status = $data['live22']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['live22']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>mannaplay <?php $status = $data['mannaplay']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="mannaplay">
					  <?php $status = $data['mannaplay']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['mannaplay']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>playstar <?php $status = $data['playstar']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="playstar">
					  <?php $status = $data['playstar']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['playstar']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Pragmaticplay <?php $status = $data['Pragmaticplay']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="Pragmaticplay">
					  <?php $status = $data['Pragmaticplay']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['Pragmaticplay']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>sagame <?php $status = $data['sagame']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="sagame">
					  <?php $status = $data['sagame']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['sagame']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>slotxo <?php $status = $data['slotxo']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="slotxo">
					  <?php $status = $data['slotxo']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['slotxo']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>spade-gaming <?php $status = $data['spadegaming']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="spadegaming">
					  <?php $status = $data['spadegaming']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['spadegaming']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>WazdanDirect <?php $status = $data['WazdanDirect']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="WazdanDirect">
					  <?php $status = $data['WazdanDirect']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['WazdanDirect']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>ambslot <?php $status = $data['ambslot']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="ambslot">
					  <?php $status = $data['ambslot']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['ambslot']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>funkygames <?php $status = $data['funkygames']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="funkygames">
					  <?php $status = $data['funkygames']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['funkygames']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>jili <?php $status = $data['jili']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="jili">
					  <?php $status = $data['jili']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['jili']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
				  <div class="col">
					<div class="form-group">
					  <p><label>Simpleplay <?php $status = $data['simpleplay']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="simpleplay">
					  <?php $status = $data['simpleplay']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['simpleplay']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>
          <div class="col">
					<div class="form-group">
					  <p><label>Micro Gaming <?php $status = $data['micro']; if($status == 1){ echo "<p style='color:#00dc1b;'><i class='fas fa-lock-open'></i> : เปิด</p>";} else { echo "<p style='color:#e80000;'><i class='fas fa-lock'></i> : ปิด</p>"; } ?></label></p>
					  <label>
					  <select name="micro">
					  <?php $status = $data['micro']; if($status == 0){ echo "<option value='0'>ตอนนี้ : ปิด</option>";} ?>
					  <?php $status = $data['micro']; if($status == 1){ echo "<option value='1'>ตอนนี้ : เปิด</option>";} ?>
					    <option value="0">ปิด</option>
					    <option value="1">เปิด</option>
                       </select>
					  </label>
					</div>
				  </div>

				  

				  
			</div>

				  
				  
				  
</div>
				
				
                <br>
                <div class="row"> 
                  </div>
                  <div class="col">
                    <div class="form-group text-right">
                      <button type="submit" id="btn_save_website" class="btn btn-primary btn-lg"><i class="fas fa-save fa-lg"></i> SAVE</button>
                      <button type="button" class="btn btn-danger btn-lg" onClick="window.location.href='member.php'"><i class="fas fa-times fa-lg"></i> CANCEL</button>
                    </div>
                  </div>
                </div>

              </form>
            </div>

          </div>
        </div>
        <!-- End Edit User -->

        <!-- Show Login Tab -->
        <div class="tab-pane fade" id="login" role="tabpanel" aria-labelledby="login-tab">
          <div class="container bg-dark" style="padding: 2%;">

            <table class="table table-light table-striped table-hove table-sm text-center table-bordered">
              <thead class="thead-dark">
                <th>No. #</th>
                <th>Time</th>
              </thead>
              <tbody>
                <?php
                  if ($data['login_log'] != "") {
                      $strlog = json_decode($data['login_log'], true);
                      for ($i=0;$i<count($strlog);$i++) {
                          ?>
                <tr>
                  <td><?php echo $i+1 ?></td>
                  <td class="text-left"><?php echo $strlog[$i];
                          if ($i==0) {
                              echo "<p style='color: red;font-weight: bold;font-style: oblique;'>Lastest</span>";
                          } ?></td>
                </tr>
                <?php
                      }
                  } else {
                      echo '<tr><td colspan="2">No matching records found</td></tr>';
                  }?>

              </tbody>
            </table>

          </div>
        </div>
        <!-- End Show Login -->

        <!-- Show Refill Tab -->
        <div class="tab-pane fade" id="refill" role="tabpanel" aria-labelledby="refill-tab">
          <div class="container bg-dark" style="padding: 2%;">

            <table class="table table-light table-striped table-hove table-sm text-center table-bordered">
              <thead class="thead-dark">
                <th>No. #</th>
                <th>Credit</th>
                <th>Time</th>
              </thead>
              <tbody>
                <?php
                    if ($data['refill_log'] != "") {
                        $strlog = json_decode($data['refill_log'], true);
                        $no = 1;
                        foreach ($strlog as $value) {
                            ?>
                <tr>
                  <td><?php echo $no ?></td>
                  <td><?php echo $value['credit']; ?></td>
                  <td class="text-left"><?php echo $value['time'];
                            if ($no==1) {
                                echo "<p style='color: red;font-weight: bold;font-style: oblique;'>Lastest</span>";
                            } ?>
                  </td>
                </tr>
                <?php $no++;
                        }
                    } else {
                        echo '<tr><td colspan="3">No matching records found</td></tr>';
                    }?>

              </tbody>
            </table>

          </div>
        </div>
        <!-- End Refill Tab -->
		
		<!-- Show Topup Tab -->
        <div class="tab-pane fade" id="Topup" role="tabpanel" aria-labelledby="Topup-tab">
          <div class="container bg-dark" style="padding: 2%;">

            <table class="table table-light table-striped table-hove table-sm text-center table-bordered">
              <thead class="thead-dark">
                <th>No. #</th>
				<th>Amount</th>
				<th>Rate</th>
                <th>Credit Get</th>
                <th>Time</th>
              </thead>
              <tbody>
                <?php
				$no = 1;
				    $sql = "SELECT * FROM `tw_log` WHERE uid = '{$userid}'";
					$result = mysqli_query($db, $sql);
					$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    if (count($rows) != 0) {
                        foreach($rows as $value){

                            ?>
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $value['sender_amount']; ?></td>
				  <td><?php echo $value['u_rate']; ?></td>
				  <td><?php echo $value['u_credit']; ?></td>
                  <td class="text-left"><?php echo $value['created_at'];
                            if ($no==1) {
                                echo "<p style='color: red;font-weight: bold;font-style: oblique;'>Lastest</span>";
                            } ?>
                  </td>
                </tr>
                <?php $no++;
                        }
                    } else {
                        echo '<tr><td colspan="5">No matching records found</td></tr>';
                    }?>

              </tbody>
            </table>

          </div>
        </div>
        <!-- End Topup Tab -->
		
		<!-- Show kb Tab -->
        <div class="tab-pane fade" id="kb" role="tabpanel" aria-labelledby="kb-tab">
          <div class="container bg-dark" style="padding: 2%;">

            <table class="table table-light table-striped table-hove table-sm text-center table-bordered">
              <thead class="thead-dark">
                <th>No. #</th>				
				<th>Chanel</th>
				<th>Type</th>
				<th>Date/Time</th>
				<th>Amount</th>
				<th>Rate</th>
                <th>Credit Get</th>
                <th>Time</th>
              </thead>
              <tbody>
                <?php
				$no = 1;
				    $sql = "SELECT * FROM `kbank_log` WHERE uid = '{$userid}'";
					$result = mysqli_query($db, $sql);
					$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
                    if (count($rows) != 0) {
                        foreach($rows as $value){

                            ?>
                <tr>
                  <td><?php echo $no; ?></td>
				  <td><?php echo $value['bank_chanel']; ?></td>
				  <td><?php echo $value['bank_type']; ?></td>
				  <td><?php echo $value['bank_date']; ?> <?php echo $value['bank_time']; ?></td>
                  <td><?php echo $value['bank_amount']; ?></td>
				  <td><?php echo $value['u_rate']; ?></td>
				  <td><?php echo $value['u_credit']; ?></td>
                  <td class="text-left"><?php echo $value['create_at'];
                            if ($no==1) {
                                echo "<p style='color: red;font-weight: bold;font-style: oblique;'>Lastest</span>";
                            } ?>
                  </td>
                </tr>
                <?php $no++;
                        }
                    } else {
                        echo '<tr><td colspan="5">No matching records found</td></tr>';
                    }?>

              </tbody>
            </table>

          </div>
        </div>
        <!-- End Topup Tab -->

      </div>
    </div>
  </main>

</body>

</html>
<?php if ($_SESSION["Permit"] == '99'): ?>
<script type="text/javascript">
  function deleteUser() {
    Swal.fire({
      title: 'Delete User [ <?php echo $data['uname']; ?> ]',
      text: "Are you sure to delete this User?่",
      type: 'question',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#28a745',
      confirmButtonText: 'Yes!'
    }).then((result) => {
      if (result.value) {
        Swal.fire({
          title: 'Confirm Delete',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#dc3545',
          cancelButtonColor: '#28a745',
          confirmButtonText: 'Delete User!',
          reverseButtons: true
        }).then((result) => {
          if (result.value) {
            $.ajax({
              type: "POST",
              url: "database/delUser.php",
              data: { uid : <?php echo $data['id']; ?> },
              beforeSend: function() {
                document.getElementById("overlay").style.display = "block";
              },
              success: function(data) {
                document.getElementById("overlay").style.display = "none";
                console.log(data);
                if (data == "deleted") {
                  Swal.fire(
                    'Deleted!',
                    'User [ <?php echo $data['uname']; ?> ] has been deleted.',
                    'success'
                  );
                  setTimeout(function(){ window.location.href = "member.php"; }, 1500);
                } else if (data == 'logout') {
                  window.location.href = "database/logout.php";
                } else {
                  Swal.fire(
                    'Error!',
                    "Can't Delete This User",
                    'error'
                  );
                }

              },
              error: function(jqXHR, textStatus, errorThrown) {
                document.getElementById("overlay").style.display = "none";
                window.location.href = "login.php";
              }
            });


          }
        })
      }
    })

  }
</script>
<?php endif; ?>
