<?php
    $servername = "localhost";
    $servname = "biddo_aihack999";
    $servpass = "E^x38wp9";
    $serv_db = "biddo_aihack999";
    $db = mysqli_connect($servername, $servname, $servpass, $serv_db);
    mysqli_set_charset($db, 'utf8');
 ?>
