<?php
session_start();
if( isset($_SESSION["ID"])  )
{
  require 'connection.php';
  $sessionID = session_id();
      $sql = " SELECT `token` FROM `users` WHERE `token` = '$sessionID' AND `type` >= '90' AND `status` = '0' AND `id` = ".$_SESSION['ID'];
  $result = mysqli_query($db,$sql);
  $data = mysqli_fetch_array($result,MYSQLI_ASSOC);
  if(!$data){
    session_destroy();
    echo '<script type="text/javascript">';
    echo 'sessionStorage.clear();';
    echo 'window.location.href = "login.php";';
    echo '</script>';
    exit();
  }
  // mysqli_close($db);
} else {
  session_destroy();
  echo '<script type="text/javascript">';
  echo 'sessionStorage.clear();';
  echo '</script>';
  header("location: login.php");
  exit();
}

  $namesite = mysqli_real_escape_string($db,$_POST['namesite']);
  $title = mysqli_real_escape_string($db,$_POST['title']);
  $description = mysqli_real_escape_string($db,$_POST['description']);
  $keyword = mysqli_real_escape_string($db,$_POST['keyword']);
  $line = mysqli_real_escape_string($db,$_POST['line']);
  
  $slotpg = mysqli_real_escape_string($db,$_POST['slotpg']);
  $AllWaySpin = mysqli_real_escape_string($db,$_POST['AllWaySpin']);
  $Ameba = mysqli_real_escape_string($db,$_POST['Ameba']);
  $Askmebet = mysqli_real_escape_string($db,$_POST['Askmebet']);
  $booongo = mysqli_real_escape_string($db,$_POST['booongo']);
  $dragon = mysqli_real_escape_string($db,$_POST['dragon']);
  $Evoplay = mysqli_real_escape_string($db,$_POST['Evoplay']);
  $FunTaGaming = mysqli_real_escape_string($db,$_POST['FunTaGaming']);
  $gamatron = mysqli_real_escape_string($db,$_POST['gamatron']);
  $IconicGaming = mysqli_real_escape_string($db,$_POST['IconicGaming']);
  $joker = mysqli_real_escape_string($db,$_POST['joker']);
  $Kagaming = mysqli_real_escape_string($db,$_POST['Kagaming']);
  $live22 = mysqli_real_escape_string($db,$_POST['live22']);
  $mannaplay = mysqli_real_escape_string($db,$_POST['mannaplay']);
  $playstar = mysqli_real_escape_string($db,$_POST['playstar']);
  $Pragmaticplay = mysqli_real_escape_string($db,$_POST['Pragmaticplay']);
  $sagame = mysqli_real_escape_string($db,$_POST['sagame']);
  $slotxo = mysqli_real_escape_string($db,$_POST['slotxo']);
  $spadegaming = mysqli_real_escape_string($db,$_POST['spadegaming']);
  $WazdanDirect = mysqli_real_escape_string($db,$_POST['WazdanDirect']);
  $ambslot = mysqli_real_escape_string($db,$_POST['ambslot']);
  $funkygames = mysqli_real_escape_string($db,$_POST['funkygames']);
  $jili = mysqli_real_escape_string($db,$_POST['jili']);
  $simpleplay = mysqli_real_escape_string($db,$_POST['simpleplay']);
  $micro = mysqli_real_escape_string($db,$_POST['micro']);
  
  $bglogin = mysqli_real_escape_string($db,$_POST['bglogin']);
  $bghome = mysqli_real_escape_string($db,$_POST['bghome']);
  $decreditball = mysqli_real_escape_string($db,$_POST['decreditball']);
  $decreditslot = mysqli_real_escape_string($db,$_POST['decreditslot']);
  $imglogo = mysqli_real_escape_string($db,$_POST['imglogo']);
  $imglogohome = mysqli_real_escape_string($db,$_POST['imglogohome']);

  $sql = " UPDATE `setting` SET 
          `namesite` = '$namesite' ,
		   `title` = '$title' ,
		    `description` = '$description',
			`keyword` = '$keyword',
			`line` = '$line',
			
			`slotpg` = '$slotpg',
			`AllWaySpin` = '$AllWaySpin',
			`Ameba` = '$Ameba',
			`Askmebet` = '$Askmebet',
			`booongo` = '$booongo',
			`dragon` = '$dragon',
			`Evoplay` = '$Evoplay',
			`FunTaGaming` = '$FunTaGaming',
			`gamatron` = '$gamatron',
			`IconicGaming` = '$IconicGaming',
			`joker` = '$joker',
			`Kagaming` = '$Kagaming',
			`live22` = '$live22',
			`mannaplay` = '$mannaplay',
			`playstar` = '$playstar',
			`Pragmaticplay` = '$Pragmaticplay',
			`sagame` = '$sagame',
			`slotxo` = '$slotxo',
			`spadegaming` = '$spadegaming',
			`WazdanDirect` = '$WazdanDirect',
			`bglogin` = '$bglogin',
			`bghome` = '$bghome',
			`decreditball` = '$decreditball',
			`decreditslot` = '$decreditslot',
			`imglogo` = '$imglogo',
			`imglogohome` = '$imglogohome',
			`ambslot` = '$ambslot',
			`funkygames` = '$funkygames',
			`jili` = '$jili',
			`simpleplay` = '$simpleplay',
      `micro` = '$micro'
			
			 WHERE `id` = '1'";
  $result = mysqli_query($db,$sql);
  if($result)
  {
    mysqli_close($db);
    header('Location: ../setting.php');
  } else {
    mysqli_close($db);
    echo mysqli_error($result);
  }
?>
