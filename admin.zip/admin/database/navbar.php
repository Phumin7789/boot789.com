<?php include "resource/modal.php"; ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
  <a class="navbar-brand" href="main.php"><img src="resource/images/new/Logo_SAhacker.png" style="height: 100%;"></a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarCollapse">
    <form class="form-inline ml-auto">
<a class="menu" href="setting.php">
        
      <a class="menu" href="#" data-toggle="modal" data-target="#CodeModal">
        <i class="fas fa-barcode"></i> สร้างโค้ดเติมเงิน</a>
      <a class="menu" href="member.php">
        <i class="fas fa-users"></i> จัดการสมาชิก</a>
      <a class="menu" href="#" data-toggle="modal" data-target="#CreateModal">
        <i class="fas fa-user-plus"></i> สร้างสมาชิก</a>
        <?php if ($_SESSION['Permit'] == 99): ?>
		<!--<a class="menu" href="#" data-toggle="modal" data-target="#WalletModal">
        <i class="fas fa-wrench"></i> Get Token Wallet</a>-->
		<!-- <a class="menu" href="#" data-toggle="modal" data-target="#KbankModal">
        <i class="fas fa-wrench"></i> KBank Setting</a> -->
          <a class="menu" href="formula.php">
            <i class="fas fa-coins"></i> แก้ไขสูตรบาคาร่า</a>
          <a class="menu" href="Summary.php">
            <i class="fas fa-poll"></i> ตรวจสอบแอดมิน</a>
			<i class="fas fa-cog"></i> ตั้งค่าเว็บ</a>
          <!-- <a class="menu" href="#" data-toggle="modal" data-target="#FootModal">
            <i class="fas fa-mobile-alt"></i> ไลน์ติดต่อ</a> -->
        <?php endif; ?>

      <a href="#" data-toggle="modal" data-target="#OutModal" style="margin-right: 1em;">
        <img src="resource/images/new/Icon_Logout.png" style="height:32px;margin-top: 5px">
      </a>
 

    </form>
  </div>
</nav>
<script type="text/javascript">
  function changeForType(type) {
    sessionStorage.forType = type;
    window.location.replace("formula.php");
  }
</script>
